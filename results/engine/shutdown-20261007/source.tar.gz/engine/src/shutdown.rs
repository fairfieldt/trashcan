//! Cooperative cancellation for host-driven GPU queues. Signal handlers only set an atomic flag;
//! normal Rust error unwinding releases submissions and waits for retirement before process exit.
use std::sync::{atomic::{AtomicI32, Ordering}, OnceLock};

static SIGNAL: AtomicI32 = AtomicI32::new(0);

extern "C" fn cancel(signal: libc::c_int) {
    // Lock-free on the supported targets. Keep the first signal's exit status.
    let _ = SIGNAL.compare_exchange(0, signal, Ordering::Relaxed, Ordering::Relaxed);
}

pub fn install() -> anyhow::Result<()> {
    static INSTALLED: OnceLock<i32> = OnceLock::new();
    let error = *INSTALLED.get_or_init(|| unsafe {
        let mut action: libc::sigaction = std::mem::zeroed();
        action.sa_sigaction = cancel as extern "C" fn(libc::c_int) as libc::sighandler_t;
        libc::sigemptyset(&mut action.sa_mask);
        for signal in [libc::SIGINT, libc::SIGTERM, libc::SIGHUP] {
            if libc::sigaction(signal, &action, std::ptr::null_mut()) != 0 {
                return std::io::Error::last_os_error().raw_os_error().unwrap_or(libc::EINVAL);
            }
        }
        0
    });
    anyhow::ensure!(error == 0, "installing cancellation handlers: {}", std::io::Error::from_raw_os_error(error));
    check()
}

pub fn signal() -> i32 { SIGNAL.load(Ordering::Relaxed) }

pub fn check() -> anyhow::Result<()> {
    anyhow::ensure!(signal() == 0, "interrupted by signal {}", signal());
    Ok(())
}

pub fn check_io() -> std::io::Result<()> {
    if signal() == 0 { Ok(()) } else { Err(std::io::Error::new(std::io::ErrorKind::Interrupted, "cancelled")) }
}
